/**
 * 
 */
package com.BPM.Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.BPM.Base.TestBase;

/**
 * @author yemam
 *
 */
public class ResultsPage extends TestBase
{
	WebDriver driver;
	
	public ResultsPage(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void DisplayResults()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("pn")));
		
		List<WebElement> SearchResultsTitles = driver.findElements(By.cssSelector(".rc > .r > a"));
		System.out.println(SearchResultsTitles.size() + " results appear");
		
		for (WebElement result : SearchResultsTitles)
		{
			System.out.println("Result Title: " + result.getText().toString());
			System.out.println("Result Link: " + result.getAttribute("href"));
			System.out.println();
		}
		
		
	}

}
