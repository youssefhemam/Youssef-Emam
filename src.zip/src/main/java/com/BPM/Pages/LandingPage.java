/**
 * 
 */
package com.BPM.Pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.BPM.Base.TestBase;

/**
 * @author yemam
 *
 */
public class LandingPage extends TestBase
{
	WebDriver driver;
	//int NumOfColumnsToTask = (Integer) prop.get("NumOfColumnsToTask");
	//int GoToTask = (Integer) prop.get("GoToTask");
	//By SearchField = By.name("wlctdc:j_id__ctru10:r1:0:tldc:keywordFilter");
	
	public LandingPage(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void CheckPageNotification()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("og-pdp")));

		WebElement Notification = driver.findElement(By.cssSelector("#viewport > div.og-pdp > div"));
		String NotificationColor = prop.getProperty("NotificationColor");		

		if (Notification.getCssValue("background-color").contentEquals(NotificationColor.toString().trim()))
		{
			System.out.println("Notification Color appears as required. Actual Result = "+ Notification.getCssValue("background-color"));
		}
		else
			System.out.println("Notification Color issue");
	}
	
	public void CheckPageButtonsandLinks()
	{
		Boolean LoginBTNisPresent = driver.findElements(By.id("gb_70")).size() > 0;
		Boolean SearchisPresent = driver.findElements(By.name("btnK")).size() > 0;
		Boolean LuckyisPresent = driver.findElements(By.name("btnI")).size() > 0;
		
		if (LoginBTNisPresent)
		{
			System.out.println("Login Button appears successfully");
		}
		else
			System.out.println("Login Button is missing");
		
		if (SearchisPresent)
		{
			System.out.println("Search Button appears successfully");
		}
		else
			System.out.println("Search Button is missing");
		
		if (LuckyisPresent)
		{
			System.out.println("Feeling Lucky Button appears successfully");
		}
		else
			System.out.println("Feeling Lucky Button is missing");
		
		String Lang = driver.findElement(By.tagName("html")).getAttribute("lang");
		Boolean exists = driver.findElements(By.id("gb_70")).size() == 0;
		
		if (Lang.contains("ar"))
		{
			Boolean InputTools = driver.findElements(By.id("gb_70")).size() > 0;
			if(InputTools)
			{
				System.out.println("Input Tools appear for the "+Lang+"version");
			}
			else
				System.out.println("Input Tools do not exist for the "+Lang+"version");
		}
		else if (exists)
			System.out.println("Input Tools do not exist for the "+Lang+"version");	
	}
	
	public void SwitchLanguage()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);		
		String Lang = driver.findElement(By.tagName("html")).getAttribute("lang");

		WebElement SwitchLink = driver.findElement(By.cssSelector("#SIvCob > a"));
		System.out.println("Language before switching is: "+ Lang.toString());
		SwitchLink.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("footer")));
		Lang = driver.findElement(By.tagName("html")).getAttribute("lang");
		System.out.println("Language after switching is: "+ Lang.toString());			
	}
	
	public void SearchValidation()
	{
		WebElement SearchBTN = driver.findElement(By.name("btnK"));
		try
		{
			SearchBTN.click();
		}
		catch (Exception e)
		{
			System.out.println("Button is disabled");
		}
	}
	
	public void PerformSearch(String input)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement SearchBar = driver.findElement(By.name("q"));
		SearchBar.sendKeys(input);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".erkvQe > li")));
		List<WebElement> SuggestionsList = driver.findElements(By.cssSelector(".erkvQe > li"));

		if(SuggestionsList.size() == 10)
		{
			System.out.println(SuggestionsList.size() + " suggestions appear");
			System.out.println("Suggestions are as follows:");
			for (WebElement suggestion : SuggestionsList)
			{
				System.out.println(suggestion.getText().toString());
			}
		}
		WebElement SearchBTN = driver.findElement(By.name("btnK"));
		SearchBTN.click();

	}

}