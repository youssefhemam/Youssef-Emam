/**
 * 
 */
package com.BPM.Base;

import java.awt.AWTException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.BPM.Pages.LoginPage;
import com.BPM.Pages.UserInbox;

/**
 * @author yemam
 *
 *Common functions will be put here
 */
public class TestBase
{
	public static WebDriver driver;
	public static Properties prop;
	public static Logger logger;
	
	public TestBase() {
		try {

			String propFilePath = System.getProperty("user.dir") + "\\src\\main\\java\\com\\BPM\\Config\\config.properties";
			prop = new Properties();
			FileInputStream input = new FileInputStream(propFilePath);
			prop.load(input);

		} catch (FileNotFoundException e) {
			logger.error("Test base Constructor " + e.getMessage());

		} catch (IOException e) {
			logger.error("Test base Constructor " + e.getMessage());

		}
	}
	
	public void OpenBrowser() {
		logger = Logger.getLogger("Login");

		String BrowserType = prop.getProperty("Browser");
		String URL = prop.getProperty("URL");

		try {

			if (BrowserType.trim().contains("Chrome")) {

				System.setProperty("webdriver.chrome.driver",
						System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe");

				// Initialize browser
				driver = new ChromeDriver();

				// Open the URL
				logger.info("Opening Browser ...");
				logger.info("Open URL = " + URL);
				driver.get(URL);
				driver.manage().window().maximize();
				Thread.sleep(1000);
			}

			else if (BrowserType == "FireFox") {

			} 
		} catch (Exception ex) {
			logger.error("Open Browser" + ex.getMessage());
		}

	}
	
	public static void CloseBrowser() {
		try {

			logger.info("Closing Browser ...");
			driver.close();
			driver.quit();
			
		} catch (Exception e) {
			logger.error("Close Browser" + e.getMessage());
		}
	}
	
	public void LoginUW() throws InterruptedException, AWTException
	{
		ArrayList<String> UnderwriterUsers = new ArrayList<String>();
		UnderwriterUsers.add(prop.getProperty("jwriter1"));
		UnderwriterUsers.add(prop.getProperty("jwriter2"));
		UnderwriterUsers.add(prop.getProperty("jwriter3"));
		UnderwriterUsers.add(prop.getProperty("swriter1"));
		UnderwriterUsers.add(prop.getProperty("swriter2"));
		UnderwriterUsers.add(prop.getProperty("swriter3"));
		UnderwriterUsers.add(prop.getProperty("mwritergiza1"));
		UnderwriterUsers.add(prop.getProperty("mwritergiza2"));
		UnderwriterUsers.add(prop.getProperty("cwriter1"));
		
		String CaseID = prop.getProperty("CaseID");
		
		LoginPage login = new LoginPage(driver);
		UserInbox inbox = new UserInbox(driver);
		
		for (int i=0; i < UnderwriterUsers.size(); i++)
		{
			OpenBrowser();
			login.typeUserName(UnderwriterUsers.get(i).toString().trim());
			login.typePassword("welcome1");
			login.clickOnLoginBtn();
			Thread.sleep(9000);
			inbox.SearchForCase(CaseID);
			List<WebElement> rows = driver.findElements(By.xpath("//*[@id=\"wlctdc:j_id__ctru10:r1:0:tldc:taskTable::db\"]/table/tbody/tr"));
			System.out.println(rows.size());
			
			if (rows.size()== 1)
			{
				System.out.println("Task is found at User" + UnderwriterUsers.get(i).toString());
				break;
			}
			else
			{
				CloseBrowser();
			}
		}
	}
	
	public void LoginIssuance() throws InterruptedException, AWTException
	{
		ArrayList<String> IssuanceUsers = new ArrayList<String>();
		IssuanceUsers.add(prop.getProperty("issuer1"));
		IssuanceUsers.add(prop.getProperty("issuer1"));
		IssuanceUsers.add(prop.getProperty("issuer1"));
		
		String CaseID = prop.getProperty("CaseID");
		
		LoginPage login = new LoginPage(driver);
		UserInbox inbox = new UserInbox(driver);
		
		for (int i=0; i < IssuanceUsers.size(); i++)
		{
			OpenBrowser();
			login.typeUserName(IssuanceUsers.get(i).toString().trim());
			login.typePassword("welcome1");
			login.clickOnLoginBtn();
			Thread.sleep(9000);
			inbox.SearchForCase(CaseID);
			List<WebElement> rows = driver.findElements(By.xpath("//*[@id=\"wlctdc:j_id__ctru10:r1:0:tldc:taskTable::db\"]/table/tbody/tr"));
			System.out.println(rows.size());
			
			if (rows.size()== 1)
			{
				System.out.println("Task is found at User" + IssuanceUsers.get(i).toString());
				break;
			}
			else
			{
				CloseBrowser();
			}
		}
	}



}
