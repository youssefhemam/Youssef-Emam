/**
 * 
 */
package com.BPM.TestCases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.BPM.Base.TestBase;
import com.BPM.Pages.LandingPage;
import com.BPM.Pages.ResultsPage;

/**
 * @author yemam
 *
 */
public class GoogleSearch extends TestBase 
{
	String SearchTerm = prop.getProperty("SearchTerm");
	String Location = prop.getProperty("Country");

	@BeforeMethod
	public void beforeMethod()
	{
		OpenBrowser();
	}
	
	@Test(priority = 1)
	public void LandingTest()
	{
		LandingPage LandingPage = new LandingPage(driver);
		LandingPage.CheckPageNotification();
		LandingPage.CheckPageButtonsandLinks();
		LandingPage.SwitchLanguage();
		LandingPage.CheckPageButtonsandLinks();
	}
	
	@Test(priority = 2)
	public void SearchArabicVer()
	{
		LandingPage LandingPage = new LandingPage(driver);
		ResultsPage ResultsPage = new ResultsPage(driver);
		LandingPage.SearchValidation();
		LandingPage.PerformSearch(SearchTerm);
		ResultsPage.DisplayResults();
	}
	
	@Test(priority = 3)
	public void SearchEnglishVer()
	{
		LandingPage LandingPage = new LandingPage(driver);
		ResultsPage ResultsPage = new ResultsPage(driver);
		LandingPage.SwitchLanguage();
		LandingPage.SearchValidation();
		LandingPage.PerformSearch(SearchTerm);
		ResultsPage.DisplayResults();
	}
	
	@AfterMethod
	public void afterMethod()
	{
		CloseBrowser();
	}

}
