/**
 * 
 */
package com.BPM.TestCases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.BPM.Base.TestBase;
import com.BPM.Pages.LandingPage;
import com.BPM.Pages.ResultsPage;

/**
 * @author yemam
 *
 */
public class GoogleSearch extends TestBase 
{
	String SearchTerm = prop.getProperty("SearchTerm");
	String Location = prop.getProperty("Country");

	@BeforeMethod
	public void beforeMethod()
	{
		OpenBrowser();
	}
	
	@Test(priority = 1)
	public void LandingTest()
	{
		LandingPage LandingPage = new LandingPage(driver);
		LandingPage.CheckPageNotification(); //Checks page notification appearing
		LandingPage.CheckPageButtonsandLinks(); //validates buttons exist on the page
		LandingPage.SwitchLanguage(); // switches the language from En to Ar
		LandingPage.CheckPageButtonsandLinks(); //validates buttons exist on the page
	}
	
	@Test(priority = 2)
	public void SearchArabicVer()
	{
		LandingPage LandingPage = new LandingPage(driver);
		ResultsPage ResultsPage = new ResultsPage(driver);
		LandingPage.SearchValidation(); //Validates that no search can be carried out unless input is added
		LandingPage.PerformSearch(SearchTerm); //performs the action of searching
		ResultsPage.DisplayResults(); //outputs the results of the first page in addition to their links
	}
	
	@Test(priority = 3)
	public void SearchEnglishVer()
	{
		LandingPage LandingPage = new LandingPage(driver);
		ResultsPage ResultsPage = new ResultsPage(driver);
		LandingPage.SwitchLanguage(); //Switches the language from Ar to En
		LandingPage.SearchValidation(); //Validates that no search can be carried out unless input is added
		LandingPage.PerformSearch(SearchTerm); //performs the action of searching
		ResultsPage.DisplayResults(); //outputs the results of the first page in addition to their links
	}
	
	@AfterMethod
	public void afterMethod()
	{
		CloseBrowser();
	}

}
